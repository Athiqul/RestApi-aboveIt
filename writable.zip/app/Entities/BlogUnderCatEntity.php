<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class BlogUnderCatEntity extends Entity
{
   
}
