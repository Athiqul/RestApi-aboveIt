<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class UserAccessEntity extends Entity
{
   
}
