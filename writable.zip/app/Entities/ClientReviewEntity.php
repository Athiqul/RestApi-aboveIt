<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class ClientReviewEntity extends Entity
{
   
}
