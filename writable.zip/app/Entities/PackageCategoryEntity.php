<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class PackageCategoryEntity extends Entity
{
    
}
