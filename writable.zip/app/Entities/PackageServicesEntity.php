<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class PackageServicesEntity extends Entity
{
  
}
